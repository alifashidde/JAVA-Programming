2064018
Software Principles (MOD003484 TRI2 F01CAM) Element 011
Based on the project chosen for element 010
"Data Generator"

Readme file

to use the programme, open Eclipse IDE software.
NOTE: THIS IS A MAVEN PROJECT, YOU HAVE TO ADD A DEPENDENCY TO YOUR POM.XML FILE.
open the file containig the code,
in the source file you will find the main,
you click the main to open it,
in the top left corner of the screen, there is a green arrow pointing right,
you click it to run the programme,


Running 
when the program starts,
it creates two (2) text files,
naija.txt
alishidde.txt
naija.txt is the text file where all the histoy is being stored
alishidde.txt is the database where all the data being generated is stored

Login and Registration

you have to login with the username, password and with a two-step verification code if you are already a member of the company
if you are new to the company,
you have to register first before being able to login


this is how the data looks like in the database

First Name: Aracelis
Last Name: Metz
Full NAME: Miss Vaughn Ankunding
Email: nelly.reilly@yahoo.com
Phone Number: 610-559-6035 x5536
address: Suite 661 295 Jolanda Ridge, Jeramytown, IN 79227
Future Date: Sat Dec 03 11:32:50 GMT 2022
Past Date: Fri Dec 02 03:21:05 GMT 2022
Gender: Female
Type of Data generated:   United States
First Name: Regan
Last Name: Leannon
Full NAME: Aurea Strosin I
Email: jeffery.cummings@hotmail.com
Phone Number: 347.707.5006 x6625
address: 50259 Rosenbaum Path, Doviemouth, ND 60868
Future Date: Sat Dec 03 16:26:01 GMT 2022
Past Date: Fri Dec 02 02:26:42 GMT 2022
Gender: Female
Type of Data generated:   United States

as you can see, the program generates data of people with their addresses, email.phone nubmer
gmail, and it even indicates which locale the data is being generated. 


external sources

we have used a library called java faker
the library generates data based on the locality the user chose


Files 

the system creates a file where the history has been stored




