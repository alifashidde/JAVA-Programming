package testdata;
import java.awt.Paint;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Date;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Random;
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;


public class Login { //this is the main class
	
	
	void memorno() throws IOException{

		// just asking the user if he is registered or not
        System.out.println("Are you an active member of Redgate?: yes, no ");
        Scanner yesno = new Scanner(System.in);
        String member = yesno.nextLine();
        

        if (member.matches("no")) {
            new Login().signUp();
        } else if (member.matches("yes")){
            new Login().userName();
            new Login().password();

        }
    }

	// a simple way of registration for new members
    void signUp() throws IOException {
        System.out.println("Enter Your Device Pin to register");
        Scanner PIN1 = new Scanner(System.in);
        String PIN = PIN1.nextLine();
        System.out.println("Registration successful!");
        System.out.println("Here are your Login details");
        System.out.println("username: alifa");
        System.out.println("password: ali");
        System.out.println("Proceed to Login");
        new Login().userName();
        new Login().password();

        // writing history to file
        try {
            FileWriter f = new FileWriter("naija.txt", true);
            f.write("\nFirst Name: " + PIN);
            f.write("\nPassword: Registration Successfull");
            f.write("\n");
            f.close();
            File file = new File("naija.txt");
            Scanner c = new Scanner(file);

        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();

        }
    }

    // simple way of taking users credentials, in this case username
    void userName() throws IOException {

        System.out.println("Enter UserName");
        Scanner alifa = new Scanner(System.in);
        String user = alifa.nextLine();

        // writing user input to file history
        try {
            FileWriter f = new FileWriter("naija.txt", true);
            f.write("\nuserName: " + user);
            f.write("\n");
            f.close();
            File file = new File("naija.txt");
            Scanner c = new Scanner(file);

        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        
        // the program takes the input if the username is correct
        if (user.matches("alifa")) {
            System.out.println("UserName taken");
        } 
        // the program wont let the user to proceed if username is wrong
        else {
            System.out.println("UserName Incorrect");
            // it then calls this method to reset username
            new Login().resetuser();


        }
        }

   
        // simple of taking users credentials, in this case password
        void password () throws IOException {


            System.out.println("Enter Password");
            Scanner pass = new Scanner(System.in);
            String passwrd = pass.nextLine();

            // it writes the users input to file history
            try {
                FileWriter f = new FileWriter("naija.txt", true);
                f.write("\npassword: " + passwrd);
                f.write("\n");
                f.close();
                File file = new File("naija.txt");
                Scanner c = new Scanner(file);

            } catch (FileNotFoundException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

            // the program takes the input if the password is correct
            if (passwrd.matches("ali")) {
                System.out.println("Welcome to Redgate");
                // it then proceed for the user to authenticate by calling this method
                new Login().authentication(); 
            }
            // it wont let the user to proceed if the password is wrong
            else {
                System.out.println("Password Wrong");
                // it then calls this method for the user to reset his password
                new Login().resetpass();
            }

        }
        // this method is for resetting username if the user forgot his username
        void resetuser () throws IOException {
            // the user input his new username
            System.out.println("input new username");
            Scanner pass2 = new Scanner(System.in);
            String user2 = pass2.nextLine();
            
            System.out.println("username Changed");
        // it writes the above user input to file history
        try {
            FileWriter f = new FileWriter("naija.txt", true);
            f.write("\nchanging userName");
            f.write("\nuserName: " + user2 + " ");
            f.write("\nusername changed");
            f.write("\n");
            f.close();
            File file = new File("naija.txt");
            Scanner c = new Scanner(file);

        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }


        }
        // the method is for resetting password if the user forgot his password
        void resetpass () throws IOException {
            // the user input his new passwird
            System.out.println("input new password");
            Scanner pass1 = new Scanner(System.in);
            String password1 = pass1.nextLine();

            System.out.println("Password Changed");
            // the user re-enters his password
            System.out.println("input changed password");
            Scanner myPass = new Scanner(System.in);
            String pass = myPass.nextLine();
            // until then he can proceed to authenticate
            new Login().authentication();
            // this writes the above users input to file history
            try {
                FileWriter f = new FileWriter("naija.txt", true);
                f.write("\nchanging password");
                f.write("\npassword: " + password1);
                f.write("\npassword changed");
                f.close();
                File file = new File("naija.txt");
                Scanner c = new Scanner(file);

            } catch (FileNotFoundException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        // this method is for authenticating
        void authentication () throws IOException {
        	// this method generates random numbers in 6 digits as verification code
            new Login().randomNum(); 
            // the user puts verification code
            System.out.println("input googgle verification code");
            Scanner myPass = new Scanner(System.in);
           // int vericode = myPass.next().charAt(0);
            int vericode = myPass.next().charAt(0);
            
            // it allows the user to login only if the user enters verification code in numeric terms
            if ((vericode>='0' && vericode<= '9') || (vericode>='9' && vericode<='0') ) {
            	System.out.println("You have successfully logged in");
            //it then calls this method to connect to database	
            new Login().database();
            // it writes the above user inputs to file history
            try {
                FileWriter f = new FileWriter("naija.txt", true);
                f.write("\nverification code: " + vericode );
                f.close();
                File file = new File("naija.txt");
                Scanner c = new Scanner(file);

            } catch (FileNotFoundException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            }
            // any input from the user other than numbers, the user will have to input the verification code again	
            else {
            	System.out.println("the verification code should be nemeric terms");
            	System.out.println("Please insert your Googgle Verification Code");
            	new Login().authentication();
            }
            	/*if(vericode!= (ThreadLocalRandom.current())) {
            		
            	}*/
            	
            	
            }
            
            

        
        // this method generates random numbers in six digits
        String randomNum () throws IOException {
        	
            System.out.println("Verification Code: " + ThreadLocalRandom.current().nextInt(100000, 999999));
            return "ThreadLocalRandom.current()";

             
        }
        // this method is for the user to connect to database
        void database () throws IOException {
            System.out.println("Press Enter to connect to database");
            Scanner database = new Scanner(System.in);
            String databaseconnection = database.nextLine();
            System.out.println("Connected");
            // the program creates a file as database
            new Files().CreateFile();
            // the data has already been generated and stored to the database
            System.out.println("Your data has been generated and being stored into a Database");
            // the user can choose to open the database
            System.out.println("Do you want to open the Database?: yes, no ");
            Scanner yesno = new Scanner(System.in);
            String opendatabase = yesno.nextLine();
            // the user gets to decide weather to open the database or not
            if (opendatabase.matches("yes")) {
            	// this method is generates data
            	new Testdata().datagen();
            	// this method opens the database
            	new Files().opendatabase();
            }
            // the user gets to decide not to open the data base
            else if (opendatabase.matches("no")) {
            	
            }
            // this writes the above user input to to file history
            try {
                FileWriter f = new FileWriter("naija.txt", true);
                f.write("\nDatabase Connection:  Connected");
                f.close();
                File file = new File("naija.txt");
                Scanner c = new Scanner(file);
            } catch (FileNotFoundException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }}

        // this method display the current time and date
        void Timedate () throws IOException {

            LocalDateTime localDate = LocalDateTime.now();
            System.out.println(localDate);
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MMM dd, YYY");
            System.out.println(dtf.format(localDate));
            // this writes the above time and date to file history
            try {
                FileWriter f = new FileWriter("naija.txt", true);
                f.write("\nTimeDate: " + localDate);
                f.write("\n");
                f.close();
                File file = new File("naija.txt");
                Scanner c = new Scanner(file);

            } catch (FileNotFoundException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }



	
	/*void timeDate() throws IOException {
		
		LocalDateTime localDate = LocalDateTime.now();
	    System.out.println(localDate);
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MMM dd, YYY");
		System.out.println(dtf.format(localDate));
		
		try {
			FileWriter f = new FileWriter("naija.txt", true);
			f.write("\n\n\\nTimeDate: " +localDate );
			f.write("\n");
 		    f.close();
 		    File file = new File("naija.txt");
			Scanner c = new Scanner(file);
			
			}
		catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	void SignUp() throws IOException {
		
		System.out.println("Enter Your Device Pin to register");
		Scanner PIN1 = new Scanner(System.in);
		String PIN = PIN1.nextLine();
		
		System.out.println("Registration successful!");
		
		 try {
	            FileWriter f = new FileWriter("naija.txt", true);

	            f.write("     \n\n\n\n\n\nNot a member of Redgate");
	            f.write("\nFirst Name: " + PIN);
	            f.write("\nPassword: Registration Successfull");
	            f.write("\n");
	            f.close();
	            File file = new File("naija.txt");
	            Scanner c = new Scanner(file);

	        } catch (FileNotFoundException e) {
	            // TODO Auto-generated catch block
	            e.printStackTrace();

	        }
		
	}

     void username() throws IOException {

    	 String username = "alifa";

         System.out.println("Are you an active member of Redgate? ");
         Scanner YesNo = new Scanner(System.in);
         String yesno = YesNo.nextLine();

         if (yesno.equals("no")) {
             
             new Login().SignUp();
             
             System.out.println("Proceed to Login");
             System.out.println("input username");
             Scanner alifa = new Scanner(System.in);
             String username1 = alifa.nextLine();
             
             try {
                 FileWriter f = new FileWriter("naija.txt", true);
                 f.write("     \n\n\n\n\n\n member of Redgate");
         		 f.write("\nuserName: "+username1);
         		 f.write("\n");
         	 	 f.close();
         		 File file = new File("naija.txt");
				 Scanner c = new Scanner(file);
					
                 }
				catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
          
         }
         
         else if (yesno.equals("yes")) {


             System.out.println("input your username");
             Scanner signUp = new Scanner(System.in);
             String username1 = signUp.nextLine();

             if (username1.matches("alifa")) {
                
                 System.out.println("username taken");
                 try {
                    FileWriter f = new FileWriter("naija.txt", true);
             		f.write("         \n\n\n\n\n\nMember of Redgate");
             		f.write("\nusername: "+username1+" ");
             		f.write("\n");
             		f.close();
             		File file = new File("naija.txt");
                    Scanner c = new Scanner(file);
    					
                     }
    				catch (FileNotFoundException e) {
    					// TODO Auto-generated catch block
    					e.printStackTrace();
    				}


             } else {
                 System.out.println("username not taken");

                 System.out.println("input registered email to change username ");
                 Scanner Mypass = new Scanner(System.in);
                 String registeredemail = Mypass.nextLine();
                 
                 try {
                     FileWriter f = new FileWriter("naija.txt", true);
             		f.write("email: "+registeredemail+" ");
             		f.write("\n");
             		f.close();
             		File file = new File("naija.txt");
                    Scanner c = new Scanner(file);
    					
                     }
    				catch (FileNotFoundException e) {
    					// TODO Auto-generated catch block
    					e.printStackTrace();
    				}

                 if (registeredemail.matches("ams335")) {
                     System.out.println("input new username");
                     Scanner myPass = new Scanner(System.in);
                     String userName = myPass.nextLine();
                     System.out.println("username changed");
                     System.out.println("input username ");
                     Scanner signUp1 = new Scanner(System.in);
                     String newusername = signUp1.nextLine();
                     
                     try {
                        FileWriter f = new FileWriter("naija.txt", true);
                 		f.write("\n\n\nchanging userName");
                 		f.write("\nuserName: "+userName+" ");
                 		f.write("\nusername changed");               		
                 		f.write("\n");
                 		f.close();
                 	    File file = new File("naija.txt");
        				Scanner c = new Scanner(file);
        					
                         }
        				catch (FileNotFoundException e) {
        					// TODO Auto-generated catch block
        					e.printStackTrace();
        				}
                  
                     
                     
                 } else {
                     System.out.println("email incorrect");
                     System.out.println("please contact your company to give you access");
                 }

             
         }
         }
     }
     
     void password() throws IOException {
            	 
            	  
             System.out.println("input your password");
             Scanner log1 = new Scanner(System.in);
             String password = log1.nextLine();


             if (password.matches("ali")) {

                 System.out.println("Welcome to Redgate");
                 
                 new Login().randomNum();
           
                 System.out.println("input googgle verification code");
                 Scanner myPass = new Scanner(System.in);
                 String googgleverificationcode = myPass.nextLine();
                 

                 
                 try {
                 FileWriter f = new FileWriter("naija.txt", true);
         		
         		f.write("password: "+password);
         		f.write("\nGooggle verification code: "+googgleverificationcode);
         		f.write("\nLogin Status:  Successfull");
         		f.write("\nDatabase Connection:  Connected");
         		f.close();
         	    File file = new File("naija.txt");
                Scanner c = new Scanner(file);
					
                 }
				catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
         		
                 
                 
         		 System.out.println("login successful");
                 System.out.println("Press ENTER to connect to datbase");
                 Scanner database = new Scanner(System.in);
                 String databaseconnection = database.nextLine();
                 System.out.println("Connected");
                 

             } else {
                 System.out.println("password incorrect");
                 System.out.println("input registered email to change password");
                 Scanner Mypass = new Scanner(System.in);
                 String registeredemail = Mypass.nextLine();
             
                 
             
             
             

                 
                 
				if (registeredemail.matches("ams335")) {
                     System.out.println("input new password");
                     Scanner myPass = new Scanner(System.in);
                     String password1 = myPass.nextLine();
                     System.out.println("password changed");
                     System.out.println("input password to login");
                     Scanner newPass = new Scanner(System.in);
                     String log = newPass.nextLine();
                     System.out.println("Welcome to Redgate");
                     
                     System.out.println("Googgle verification code");

                     
                     System.out.println("input googgle verification code");
                     Scanner vericode = new Scanner(System.in);
                     String code1 = vericode.nextLine();
                     
                    
                     System.out.println("login successful");
                     System.out.println("Press ENTER to connect to datbase");
                     Scanner database = new Scanner(System.in);
                     String databaseconnection = database.nextLine();
                     System.out.println("Connected");
                     
                    /* try {
    	                 FileWriter f = new FileWriter("naija.txt", true);
    	                 
    	         		f.write("password: "+log);
    	         		f.write("\n\nGooggle verification code: "+code);
    	         		
    	         		f.close();
    	         		
    	         		File file = new File("naija.txt");
    	                 
    						Scanner c = new Scanner(file);
    						
    	                 }
    					catch (FileNotFoundException e) {
    						// TODO Auto-generated catch block
    						e.printStackTrace();
    					}*/
                     
                     
              /*   } else {
                     System.out.println("email incorrect");
                     System.out.println("please contact your company to give you access");
                 }
             
				
	         		
				
             }
         
     }
             String randomNum() {
            	 
            	 System.out.println("Verification Code: " +ThreadLocalRandom.current().nextInt(100000, 999999));
				return "ThreadLocalRandom.current()";
	
            	 
             }*/
             
             
     
     }


