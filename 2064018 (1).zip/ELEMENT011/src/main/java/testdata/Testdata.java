package testdata;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
import java.util.Scanner;
import java.sql.*;
import com.github.javafaker.Faker;
public class Testdata {
	
	void datagen() throws IOException{
		System.out.println("choose Locale: en-CA, en-US, ru, zh-CN");
		Scanner userinput = new Scanner(System.in);
		String userinput1 = userinput.nextLine();
		
		if (userinput1.matches("en-CA")) { 
		
			new Testdata().canada(); // this method is called, if the user chose the locale of type canada
		}
		else if (userinput1.matches("en-US")) {
			new Testdata().america(); // this method is called, if the user chose the locale of type america
			
		}
		else if(userinput1.matches("ru")) {
			new Testdata().russia(); // this method is called, if the user chose the locale of type Russia
		}
		else if(userinput1.matches("zh-CN")) {
			new Testdata().china(); // this method is called, if the user chose the locale of type China
		}
		}
	
	void china() throws IOException {
		
	    // this loop enables the library to generate two sets of data
		for (int i=0;i<2;i++) {
			
			Faker fake= new Faker(new Locale("zh-CN"));
			
			try {
			    FileWriter f = new FileWriter("alishidde.txt", true);
			   	
				f.write("\nFirst Name: "+fake.name().firstName()+""); // this generates a fake first name
				f.write("\nLast Name: "+fake.name().lastName());  // this generates a fake last name
				f.write("\nFull NAME: "+fake.name().fullName()); // this generates a combines the full name name
				f.write("\nEmail: " +fake.internet().emailAddress()); // this generates a fake email address
				f.write("\nPhone Number: " +fake.phoneNumber().phoneNumber()); // this generates a fake phone number
				f.write("\naddress: " +fake.address().fullAddress());  // this generates a fake full address
				f.write("\nFuture Date: " +fake.date().future(1, TimeUnit.DAYS)); // this generates a fake future time 
				f.write("\nPast Date: " +fake.date().past(1, TimeUnit.DAYS)); // this generates a fake past time
				f.write("\nGender: " +fake.demographic().sex()); // this generates a fake gender
				f.write("\nType of Data generated:   China"); // it writes the type of locale to database, in this case China
				
				f.close();
				
				File file = new File("alishidde.txt");
			    
					Scanner c = new Scanner(file);
					
			    }
				catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
			
		}
	
		
	    // this method is to generate data with the locale canada
		void canada() throws IOException {
			
		    // this loop enables the library to generate two sets of data
			for (int i=0;i<2;i++) {
				
				Faker fake= new Faker(new Locale("en-CA"));
				
				try {
				    FileWriter f = new FileWriter("alishidde.txt", true);
				   	
					f.write("\nFirst Name: "+fake.name().firstName()+""); // this generates a fake first name
					f.write("\nLast Name: "+fake.name().lastName());   // this generates a fake last name
					f.write("\nFull NAME: "+fake.name().fullName()); // this generates a combines the full name name
					f.write("\nEmail: " +fake.internet().emailAddress()); // this generates a fake email address
					f.write("\nPhone Number: " +fake.phoneNumber().phoneNumber()); // this generates a fake phone number
					f.write("\naddress: " +fake.address().fullAddress());  // this generates a fake full address
					f.write("\nFuture Date: " +fake.date().future(1, TimeUnit.DAYS)); // this generates a fake future time
					f.write("\nPast Date: " +fake.date().past(1, TimeUnit.DAYS)); // this generates a fake past time
					f.write("\nGender: " +fake.demographic().sex()); // this generates a fake gender
					f.write("\nType of Data generated:   Canada"); // it writes the type of locale to database, in this case Canada
					
					f.close();
					
					File file = new File("alishidde.txt");
				    
						Scanner c = new Scanner(file);
						
				    }
					catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
				
			}
		
void russia() throws IOException {
			
		    // this loop enables the library to generate two sets of data
			for (int i=0;i<2;i++) {
				
				Faker fake= new Faker(new Locale("ru"));
				
				try {
				    FileWriter f = new FileWriter("alishidde.txt", true);
				   	
					f.write("\nFirst Name: "+fake.name().firstName()+""); // this generates a fake first name
					f.write("\nLast Name: "+fake.name().lastName()); // this generates a fake last name
					f.write("\nFull NAME: "+fake.name().fullName()); // this generates a combines the full name name
					f.write("\nEmail: " +fake.internet().emailAddress()); // this generates a fake email address
					f.write("\nPhone Number: " +fake.phoneNumber().phoneNumber()); // this generates a fake phone number
					f.write("\naddress: " +fake.address().fullAddress()); // this generates a fake full address
					f.write("\nFuture Date: " +fake.date().future(1, TimeUnit.DAYS)); // this generates a fake future time
					f.write("\nPast Date: " +fake.date().past(1, TimeUnit.DAYS)); // this generates a fake past time
					f.write("\nGender: " +fake.demographic().sex()); // this generates a fake gender
					f.write("\nType of Data generated:   Russia"); // it writes the type of locale to database, in this case Russia
					
					f.close();
					
					File file = new File("alishidde.txt");
				    
						Scanner c = new Scanner(file);
						
				    }
					catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
				
			}
			
		// this method is to generate data with locale united states
		void america() throws IOException {
			    //this loop enables the library to generate data of two sets 
                for (int i=0;i<2;i++) {
				
				
				Faker fake= new Faker(new Locale("en-US"));
	
				try {
            
	FileWriter f = new FileWriter("alishidde.txt", true);
   
    
    f.write("\nFirst Name: "+fake.name().firstName()+""); // this generates a fake first name
	f.write("\nLast Name: "+fake.name().lastName()); // this generates a fake last name
	f.write("\nFull NAME: "+fake.name().fullName()); // this generates a combines the full name name
	f.write("\nEmail: " +fake.internet().emailAddress()); // this generates a fake email address
	f.write("\nPhone Number: " +fake.phoneNumber().phoneNumber()); // this generates a fake phone number
	f.write("\naddress: " +fake.address().fullAddress());  // this generates a fake full address
	f.write("\nFuture Date: " +fake.date().future(1, TimeUnit.DAYS));  // this generates a fake future time
	f.write("\nPast Date: " +fake.date().past(1, TimeUnit.DAYS));  // this generates a fake past time
	f.write("\nGender: " +fake.demographic().sex());  // this generates a fake gender
	f.write("\nType of Data generated:   United States"); // it writes the type of locale to database, in this case the united states
	f.close();
	
	File file = new File("alishidde.txt");
    
		Scanner c = new Scanner(file);
		
    }
	catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}		
	}
	}
	
	



