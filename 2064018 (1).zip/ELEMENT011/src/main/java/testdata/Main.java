                      


     //2064018


package testdata;

import java.io.IOException;

public class Main {
	
	public static void main(String[] args)  {
		
		try {
			
			new Login().Timedate(); // this method is called in the main from the Login class
	        new Login().memorno(); // this method is called in the main from the Login class
		    new Files().ReadFile(); // this method is called in the main from the Files class
		   // new Files().exit();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
