package testdata;

import java.util.Scanner; // Import the Scanner class to read text files
import java.util.concurrent.TimeUnit; // Java program to demonstrate TimeUnit Class
import java.io.FileNotFoundException; // Import this class to handle errors
import java.io.FileReader;  // Import the FileReader class
import java.io.FileWriter;  // Import the FileWriter class
import java.io.IOException; // Import the IOException class to handle errors
import java.io.File; // Import the File class


public class Files {
	

	void ReadFile() throws FileNotFoundException {
		new Files().CreateFile1();
		System.out.println("\n\n\nDo you want to see History?: yes, no "); // the user has the choice to view the history
		Scanner yesno = new Scanner(System.in);
		String History = yesno.nextLine();
		
		if (History.matches("yes")) { // the user gets to view the history if he chose this
		
		
		File myObj = new File("naija.txt");
		Scanner myReader = new Scanner(myObj);
		
		while (myReader.hasNextLine()) {
			
			String data = myReader.nextLine();
			System.out.println(data);
		}
		myReader.close();
	}
		
	
	else if (History.matches("no")) { // the user wont be able to see history
		System.out.println("Thanks ");
		//System.exit(1);
	}  
	
}	
	
  void CreateFile() { // this method contains code of creating a text file
		  
		    try {
		      File myObj = new File("alishidde.txt");
		      if (myObj.createNewFile()) {
		        System.out.println("File created: " + myObj.getName());
		      } else {
		        System.out.println("File already exists.");
		      }
		    } catch (IOException e) {
		      System.out.println("An error occurred.");
		      e.printStackTrace(); // handle exceptions and errors
		    }
		  }
  
  void CreateFile1() {
	  
	    try {
	      File myObj = new File("naija.txt");
	      if (myObj.createNewFile()) {
	        System.out.println("File created: " + myObj.getName());
	      } else {
	        System.out.println("File already exists.");
	      }
	    } catch (IOException e) {
	      System.out.println("An error occurred.");
	      e.printStackTrace();  // handle exceptions and errors
	    }
	  }
  
  // this method is to open the database	
  void opendatabase() throws IOException {
	  
	  Runtime rt = Runtime.getRuntime();
	  String file = "C:\\Users\\HP\\Documents\\Development\\IntroToProg\\YoutubeMavenProject\\alishidde.txt"; // this is the database path
	  
	  @SuppressWarnings("deprecation")
	Process p = rt.exec("notepad "+file  );
	
  }
  
  
	
}

	
	